package com.example.demo1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class ejercicioclase extends JFrame {
    private JTextField emailField;
    private JComboBox<String> languageComboBox;
    private JCheckBox isAdminCheckBox;
    private JButton confirmButton;
    private JButton backButton;
    private JLabel statusLabel;
    private JTable userTable;
    private DefaultTableModel tableModel;

    public ejercicioclase() {
        super("Añadir Usuario");
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 2));

        JLabel emailLabel = new JLabel("Correo electrónico:");
        emailField = new JTextField();
        formPanel.add(emailLabel);
        formPanel.add(emailField);

        JLabel languageLabel = new JLabel("Idioma:");
        languageComboBox = new JComboBox<>();
        languageComboBox.addItem("Inglés");
        languageComboBox.addItem("Español");
        languageComboBox.addItem("Francés");
        formPanel.add(languageLabel);
        formPanel.add(languageComboBox);

        JLabel roleLabel = new JLabel("Rol:");
        isAdminCheckBox = new JCheckBox("Administrador");
        formPanel.add(roleLabel);
        formPanel.add(isAdminCheckBox);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        confirmButton = new JButton("Confirmar");
        confirmButton.addActionListener(new ConfirmButtonListener());
        buttonPanel.add(confirmButton);

        backButton = new JButton("Volver");
        backButton.addActionListener(new BackButtonListener());
        buttonPanel.add(backButton);

        add(buttonPanel, BorderLayout.SOUTH);

        statusLabel = new JLabel("");
        add(statusLabel, BorderLayout.PAGE_END);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Correo");
        tableModel.addColumn("Idioma");
        tableModel.addColumn("Rol");
        userTable = new JTable(tableModel);
        add(new JScrollPane(userTable), BorderLayout.EAST);

        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private class ConfirmButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String email = emailField.getText();
            String language = (String) languageComboBox.getSelectedItem();
            boolean isAdmin = isAdminCheckBox.isSelected();

            if (email.isEmpty() || language.isEmpty()) {
                statusLabel.setText("Falta algún campo por completar");
            } else {
                tableModel.addRow(new Object[]{email, language, isAdmin ? "Administrador" : ""});
                JOptionPane.showMessageDialog(ejercicioclase.this, "Usuario " + (isAdmin ? "administrador" : "") + " almacenado correctamente: " + email);
                emailField.setText("");
                languageComboBox.setSelectedIndex(0);
                isAdminCheckBox.setSelected(false);
            }
        }
    }

    private class BackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ejercicioclase();
            }
        });
    }
}
